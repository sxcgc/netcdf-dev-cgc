var searchData=
[
  ['siman_2efinc',['siman.finc',['../siman_8finc.html',1,'']]],
  ['sort_2efinc',['sort.finc',['../sort_8finc.html',1,'']]],
  ['specfunc_2efinc',['specfunc.finc',['../specfunc_8finc.html',1,'']]],
  ['splinalg_2efinc',['splinalg.finc',['../splinalg_8finc.html',1,'']]],
  ['spmatrix_2efinc',['spmatrix.finc',['../spmatrix_8finc.html',1,'']]],
  ['statistics_2efinc',['statistics.finc',['../statistics_8finc.html',1,'']]],
  ['sum_5flevin_2efinc',['sum_levin.finc',['../sum__levin_8finc.html',1,'']]]
];
